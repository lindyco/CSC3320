/* Lab04 Problem 06 */


#include <stdio.h>
#include <string.h>

int main(){
    int a, b;
    printf("Enter an integer that is less than a hundred\
    (Write in 2-digital format,eg.number two, enter as 02): ");
    scanf("%1d%1d", &a, &b);
    
    switch(a){
        case 0:
            switch(b){
                case 0:
                printf("Zero \n");
                return 0;
                
                case 1:
                printf("One \n");
                return 0;
                
                case 2:
                printf("Two \n");
                return 0;
                
                case 3:
                printf("Three \n");
                return 0;
                
                case 4:
                printf("Four \n");
                return 0;
                
                case 5:
                printf("Five \n");
                return 0;
                
                case 6:
                printf("Six \n");
                return 0;
                
                case 7:
                printf("Seven \n");
                return 0;
                
                case 8:
                printf("Eight \n");
                return 0;
                
                case 9:
                printf("Nine \n");
                return 0;
            }
            break;
            
        case 1:
            switch(b){
                case 0:
                printf("Ten \n");
                return 0;
                
                case 1:
                printf("Eleven \n");
                return 0;
                
                case 2:
                printf("Twelve \n");
                return 0;
                
                case 3:
                printf("Thirteen \n");
                return 0;
                
                case 4:
                printf("Fourteen \n");
                return 0;
                
                case 5:
                printf("Fifteen \n");
                return 0;
                
                case 6:
                printf("Sixteen \n");
                return 0;
                
                case 7:
                printf("Seventeen \n");
                return 0;
                
                case 8:
                printf("Eighteen \n");
                return 0;
                
                case 9:
                printf("Nineteen \n");
                return 0;
            }
            break;
            
        case 2:
        printf("twenty");
        break;
        
        case 3:
        printf("Thirty");
        break;
        
        case 4:
        printf("Forty");
        break;

        case 5:
        printf("Fifty");
        break;
        
        case 6:
        printf("Sixty");
        break;
        
        case 7:
        printf("Seventy");
        break;
        
        case 8:
        printf("Eighty");
        break;
        
        case 9:
        printf("Ninety");
        break;
    }
    
    switch (b){
        case 1:
        printf(" One \n");
        break;
            
        case 2:
        printf(" Two \n");
        break;
            
        case 3:
        printf(" Three \n");
        break;
            
        case 4:
        printf(" Four \n");
        break;
            
        case 5:
        printf(" Five \n");
        break;
            
        case 6:
        printf(" Six \n");
        break;
            
        case 7:
        printf(" Seven \n");
        break;
            
        case 8:
        printf(" Eight \n");
        break;
            
        case 9:
        printf(" Nine \n");
        break;
    }
    return 0;
}
