# Final Exam Problem 1

# Import python library
import os
import sys
from shutil import copy2

# Create FINALpython folder
dir1 = 'FINALpython' 
os.makedirs(dir1)

# Create subdirectory - copies
dir2 = 'FINALpython/copies' 
os.makedirs(dir2)

# Create subdirectory - encrypted
dir3 = 'FINALpython/encrypted'
os.makedirs(dir3)

# Create sudirectory - decrypted
dir4 = 'FINALpython/decryptd'
os.makedirs(dir4)

# copy of this python file and moves it into FINALpython
file1 = 'P1.py'
copy2(file1, dir1)
