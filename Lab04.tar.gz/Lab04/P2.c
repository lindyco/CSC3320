/*Lab04 Problem2*/

#include <stdio.h>
   int main(){
	char String [100];
	printf("Enter an input \n");
	scanf("%s", String);
	int i;
	i = atoi(String);
	printf("The input you entered as an integer is: %d \n",i);

}
