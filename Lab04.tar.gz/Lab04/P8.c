/* Lab04 Problem 8 */


#include <stdio.h>
#include <string.h>

int main()
{
    char a[10], b[10];
    int x, y, product;
    printf("Enter two words for integer that is less than a hundred: ");
    scanf("%s%s", a, b);
    
    x = convert(a);
    y = convert(b);
    
    printf("%d, %d\n", x, y);
    
    product = x*y;
    
    printf("The product is: %d \n", product);
    
    return 0;
}

int convert(char *c){
    int n;
    
    if(strcmp(c,"zero") == 0)
        n = 0;
    if(strcmp(c,"one") == 0)
        n = 1;
    if(strcmp(c,"two") == 0)
        n = 2;
    if(strcmp(c,"three") == 0)
        n = 3;
    if(strcmp(c,"four") == 0)
        n = 4;
    if(strcmp(c,"five") == 0)
        n = 5;
    if(strcmp(c,"six") == 0)
        n = 6;
    if(strcmp(c,"seven") == 0)
        n = 7;
    if(strcmp(c,"eight") == 0)
        n = 8;
    if(strcmp(c,"nine") == 0)
        n = 9;
    if(strcmp(c,"ten") == 0)
        n = 10;
    if(strcmp(c,"eleven") == 0)
        n = 11;
    if(strcmp(c,"twelve") == 0)
        n = 12;
    if(strcmp(c,"thirteen") == 0)
        n = 13;
    if(strcmp(c,"fourteen") == 0)
        n = 14;
    if(strcmp(c,"fifteen") == 0)
        n = 15;
    if(strcmp(c,"sixteen") == 0)
        n = 16;
    if(strcmp(c,"seventeen") == 0)
        n = 17;
    if(strcmp(c,"eigthteen") == 0)
        n = 18;
    if(strcmp(c,"nineteen") == 0)
        n = 19;
    if(strcmp(c,"twenty") == 0)
        n = 20;
    if(strcmp(c,"thirty") == 0)
        n = 30;
    if(strcmp(c,"forty") == 0)
        n = 40;
    if(strcmp(c,"fifty") == 0)
        n = 50;
    if(strcmp(c,"sixty") == 0)
        n = 60;
    if(strcmp(c,"seventy") == 0)
        n = 70;
    if(strcmp(c,"eighty") == 0)
        n = 80;
    if(strcmp(c,"ninety") == 0)
        n = 90;
    return n;
    
    return 0;
}


