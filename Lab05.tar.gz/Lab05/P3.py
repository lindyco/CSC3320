# Lab05 Problem3

Value = input("Enter a year: ")

Year = int(Value)

if Year % 4 == 0 and Year % 100 != 0 or Year % 400 == 0 :
	print("This is a leap year!")
else:
	print("This is not a leap year!")
