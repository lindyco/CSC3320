/* Assignment2 Problem2 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	FILE *input, *result;
	input = fopen(argv[1], "r");
	char c;
	unsigned char letter[26];

	while(((c = fgetc(input)) != EOF)){
		if(isalpha(c)){
		 letter[tolower(c) - 'a' ] += 1;		
		}
	}

	int i, maxChar = 0, maxCount = 0;
	for(i = 0; i < 26; i++){
		if(letter[i] >= maxCount){
			maxCount = letter[i];  
			maxChar = i;
		}
	   printf("The number for letter %c is %d\n", i+'a',letter[i]);  
	}
   printf("The most common letter is %c \n", maxChar + 'a');

	int x;
	x = abs('e' - (maxChar + 'a')); 

   printf("The possible key is %d \n", x);

	fclose(input);
	return 0;	


}
