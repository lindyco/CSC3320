# Lab06 Problem2 String:

#Import the bianry ASCII to the program:
import binascii

# Get the input data and then convert to bianry number:
input_data = raw_input("Please enter a string: ")
string_to_bin = binascii.a2b_base64(input_data.strip())
print("The binary convert by this string is: " + string_to_bin)

# Convert the binary number back to the string:
bin_to_string = binascii.b2a_base64(string_to_bin)
print("The string convert be this binary: " + bin_to_string)


