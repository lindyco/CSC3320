I am went cumoja1 directory to get the document “The Hunger Games” and then transfer to my home. 
Second I create a folder call Submission, put the document The Hunger Games to the folder and then rename to “My Hunger Games”. 
Finally, I go into the file change all Madge to Lin.

