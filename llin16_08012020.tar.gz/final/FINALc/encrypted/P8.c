// Final Exam Problem8

#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>

// Read the file in the encrypted directory
int main(int argc, char **argv){
	struct dirent* file;
	DIR* FD;
	char buffer[BUFSIZ];
	FILE *input_file;
	FILE *output_file;
	
	FD = opendir("/home/llin16/final/FINALc/encrypted/");
	while (file = readdir (FD)){
		if(!strcmp(file->d_name, "."))
			continue;
		if(!strcmp(file->d_name, ".."))
			continue;
		input_file = fopen(file->d_name, "rb");

// Open decrypted folder and encrypted the file
		char str1[80] = "/home/llin16/final/FINALc/decrypted/";
		char str2[20];
		strcpy(str2, file->d_name);
		strcat(str1, str2);
		output_file = fopen(str1, "wb");
		int c;
		int key = 150;
		while(( c = fgetc(input_file)) != EOF){
			c -= key;
			if( key - 1 > 0 )
				key = (key - 1) % 256;
			else
				key = 255; 
		fputc(c,output_file);
		}	
		fclose(input_file);
		fclose(output_file);
	}
	closedir(FD);
	return 0;
	}

