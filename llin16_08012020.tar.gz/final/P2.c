/* Final Exam Problem2 */

#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

void main(int argc, char*argv[]) {

	// Create the FINALc folder
	int dir = mkdir("FINALc", 0777);

	// Create the subdirectory copies
	mkdir("FINALc/copies", 0777);

	// Create the subdirectory encrypted
	mkdir("FINALc/encrypted", 0777);
	
	// Create the subdirectory decrypted
	mkdir("FINALc/decrypted", 0777);
	
	// copy this c program itself to FINALc folder
	system("cp P2.c FINALc");

	// Put the output to a file that I provide in the command line
	FILE *output;
	output = fopen(argv[1], "w");
	char *s = "Done";
	fprintf(output, "%c", s);
	system("gcc P2.c -o P2");
	system("./P2"); 
	
}


