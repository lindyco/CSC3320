# Lab06 Problem2 Hex Dump

#Build a funtion to read and write the binary file to hexadecimal file
def bin_to_hex(readfile, writefile):

	byte = ""
	hexa = ""
	print("String, ASCII, Hexadecimal")
	with open(readfile, "rb") as r:
		byte = r.read(1)
		while byte != "":
			print(byte, ord(byte), hex(ord(byte)))
			hexa += hex(ord(byte)) + " "
			byte = r.read(1)
	print("Hexadecimal array:")
	print(hexa)
	r = open(writefile, "w")
	r.write(hexa)
	r.close()

#Call the function
bin_to_hex("P2.txt", "P2_Hex.txt")
