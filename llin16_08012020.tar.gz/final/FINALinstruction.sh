# Final Exam Problem 4 

#! /bin/bash/

ls -l | egrep -v ^d >> listFile
awk '{if($1 != "total") {print $1, $9} else {print $0}}' listFile >> FINALinstruction

