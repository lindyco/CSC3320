# Lab05 Problem4

sum = 0
for i in range(0, 1000, 1):
	if(i % 3 == 0 or i % 5 == 0):
		sum = sum + i;

print("The sum all the integers below 1000 that are multiples of 3 or 5 is %i"% sum)
