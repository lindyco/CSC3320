# Final Exam Problem 7

import os
import sys

#Encryption to file
def encryption(txt):
	key = 150
	letter = ""
	for ch in txt:
		ch.lower()
		if(ord(ch) >= ord('a') and ord(ch) <= ord('z')):
			letter += chr((ord(ch) + key) % 256)
		else:
			letter += ch
		if(key - 1 > 0):
			key = (key - 1) % 256
		else:
			key = 255
	return letter

#read the input and write output file
for item in os.listdir(os.getcwd()):
	with open(os.path.join(os.getcwd(), item), 'rb') as r:
		input_file = r.read()
		w = open("/home/llin16/final/FINALpython/encrypted" + item, "wb")
		encrypt = encryption(input_file)
		w.write(encrypt)
		w.close()
