#Lab 06 Probelm2 DeHex:

#import the binary ASCII from the system:
import binascii

def dehexify(hexfile):
	input_data = open(hexfile, "r").read()
	dehex = binascii.hexlify(input_data)
	print(dehex)


# Execute the function::
dehexify("P2_Hex.txt") 
