# Lan05 Problem6


# Read the number that user enter:
User_input = input("Please enter a integer that is less than a hundred: ")

n = int(User_input)

word = ""
tenDigit = (n / 10) * 10
oneDigit = n % 10


# Convert number 1-19 to Word
def oneWord (value):
    switcher = {
        0: "Zero",
        1: "One",
        2: "Two",
        3: "Three",
        4: "Four",
        5: "Five",
        6: "Six",
        7: "Seven",
        8: "Eight",
        9: "Nine",
        10: "Ten",
        11: "Eleven",
        12: "Twelve",
        13: "Thirteen",
        14: "Fourteen",
        15: "fifteen",
        16: "Sixteen",
        17: "Seventeen",
        18: "Eighteen",
        19: "Nineteen",
    }
    
    return switcher.get(value, "nothing") 

# Convert number 20,30,40,50,60,70,80,90 to word    
def tenthOneWord(value):
    switcher = {
        20: "Twenty",
        30: "Thirty",
        40: "Forty",
        50: "Fifty",
        60: "Sixty",
        70: "Seventy",
        80: "Eighty",
        90: "Ninety",
    }
    
    return switcher.get(value, "nothing") 


# check if the number is 0-19 or 20-99
if(0 <= n <= 19):
    print("The integer you enter is " + oneWord(n))
elif(20 <= n < 100):
    	if oneDigit == 0:
		print("The integer you enter is " + tenthOneWord(n))
    	elif  oneDigit != 0:
        	word = tenthOneWord(tenDigit) + "-" + oneWord(oneDigit)
		print("The integer you enter is " + word)
else:
    print("This integer is out of range")
