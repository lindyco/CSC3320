/*Lab04 Problem 05 */
#include <stdio.h>

   int main(){
        int a, b, max, r, product;
        for(a = 0; a <= 999; a++){
           for(b = 0; b <= 999; b++){
               int sum = 0;
                product = a*b;
                int temp = product;

/*Check if the integer is palidrome */

             while(temp > 0){
                r = temp % 10;
                sum = sum * 10 + r;
                temp = temp / 10;
            }
             if(product == sum ){
                if(sum > max){
                   max = sum;
                }
             }
  }
 }
    printf("The largest palindrome made by the product of two and three digits number is %d \n", max);
}

