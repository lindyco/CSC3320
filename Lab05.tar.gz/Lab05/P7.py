# Lab05 Problem7

def oneWord (value):
    switcher = {
	'zero': 0,
	'one': 1,
	'two': 2,
	'three': 3,
	'four': 4,
	'five': 5,
	'six': 6,
	'seven': 7,
	'eight': 8,
	'nine': 9,
	'ten': 10,
	'eleven': 11,
	'twelve': 12,
	'thirteen': 13,
	'fourteen': 14,
	'fifteen': 15,
	'sixteen': 16,
	'seventeen': 17,
	'eighteen': 18,
	'nineteen':19,
	"twenty": 20,
        "thirty": 30,
        "forty": 40,
        "fifty": 50,
        "sixty": 60,
        "seventy": 70,
        "eighty": 80,
        "ninety": 90,
    }

    return switcher.get(value, "nothing")
  
# Get integer words 
x = raw_input("Please enter a number: ").lower()

# split them to a arry
arr = x.split("-")

# Check the integer is one-digit or two-digit and convert to integer
if len(arr) == 1:
	a = int(oneWord(arr[0])) 
elif len(arr) == 2:
	a = int(oneWord(arr[0])) + int(oneWord(arr[1]))
else:
	print("The first number you enter is out of range")

#Print the word as integer
print("The first number you enter is: " + str(a))  
