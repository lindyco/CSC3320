/* Assignment2 Problem3, Decryption */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char*argv[]){

	FILE *input, *result;
	input = fopen(argv[1], "r");
	result = fopen(argv[2], "w");
	int key = 6;
	char c;

        while((c = fgetc(input)) != EOF ){
                char ch = (char) c;
                if(ch >= 'A' && ch <= 'Z' )
                        ch = ch + 32;

                if(ch >= 'a' && ch <= 'z' ){
                        ch = ch - key;
                        if(ch < 97)
                           ch += 26;

                   fprintf(result, "%c", ch);
                } else
                   fprintf(result, "%c", (char)c);
        }

        fclose(input);
        fclose(result);

        return 0;

}
