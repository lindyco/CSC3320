/* Assignment1 Problem1 */

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char*argv[]){

/* Import the input&output file from the system, and initial the number of key*/
	FILE *input, *result;
	input = fopen(argv[1], "r");
	result = fopen(argv[2], "w");
	int key = 9;
	char s;

/* Convert the Upper case to Lower case 
 * Next, use Caesar Cipher mathematical formula to encrypt the input file
 * And then store the input file to output file after encrypt */
	while((s = fgetc(input)) > 0){
		char c = (char)s;
		
		if(c >= 'A' && c <= 'Z')
		   c += 32;
		
		if(c >= 'a' && c <= 'z') {
		   c = 97 + (c + key - 97) % 26;
		   fprintf(result, "%c", c);
		 }  else 
		   fprintf(result, "%c", (char)c);
	}

/* Close the input and output files */
	fclose(input);
	fclose(result);

	return 0;
}
