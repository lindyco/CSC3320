# Lab05 Problem5

maxnum = 0

for i in range(100, 999, 1):
	for j in range(100, 999, 1):
		product = i * j
		st = str(product)
		reverse_st = ""

# Check if the integer is palidrome, if true, check if bigger than maxnum and update maxnum
		for c in st:
			reverse_st = c + reverse_st
		if reverse_st == st :
			if maxnum < product :
				maxnum = product
print("THe laragest palindrome made by the product of two three digits number is %i" % maxnum)
