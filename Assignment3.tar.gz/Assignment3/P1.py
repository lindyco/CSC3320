# Assignment3 Problem1

import sys

#read the input and output file
input_Data = open("message1.txt").read()
f = open("result_P1.txt", "w")

key = 9
letter = ""

#Encryption to output file
for ch in input_Data:
	ch.lower()
	if(ord(ch) >= ord('a') and ord(ch) <= ord('z')):
		letter = chr(97 + (ord(ch) + key - 97) % 26)
		f.write(letter)
	else:
		f.write(ch)

# Close file
f.close()
