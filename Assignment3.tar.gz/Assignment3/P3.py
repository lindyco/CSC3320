# Assignment3 Problem3:

import sys

# Read the input and output file
input_Data = open("ceaser2.txt").read()
f = open("result_P3.txt", "w")

# Convert all the letter to lower case
input_Data.lower()

#count the number of each letter
list1  = [0] * 26

for ch in input_Data:
	if (ch.isalpha() == True):
		list1[ord(ch) - ord('a') ] += 1

# Find the most commom letter that appear
maxCount = max(list1)
maxChar = list1.index(maxCount)

for i in range(0,26,1):
	print('The letter {} appear {} times'.format(chr(i+ord('a')), list1[i]))

print("The most common letter is " + chr(maxChar+ord('a')))

# Find the key for decrytion
key = abs(ord('e') - (maxChar + ord('a')))

print("The possible key is " + str(key))


#Decrytion
for ch in input_Data:
	if( ord(ch) >= ord('a') and ord(ch) <= ord('z')):
		a = ord(ch) - key;
		if( a < 97):
			a += 26
		f.write(chr(a))
	else:
		f.write(ch)



f.close()

