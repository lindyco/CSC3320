# Lab05 Problem8

def oneWord (value):
    switcher = {
	'zero': 0,
	'one': 1,
	'two': 2,
	'three': 3,
	'four': 4,
	'five': 5,
	'six': 6,
	'seven': 7,
	'eight': 8,
	'nine': 9,
	'ten': 10,
	'eleven': 11,
	'twelve': 12,
	'thirteen': 13,
	'fourteen': 14,
	'fifteen': 15,
	'sixteen': 16,
	'seventeen': 17,
	'eighteen': 18,
	'nineteen':19,
	"twenty": 20,
        "thirty": 30,
        "forty": 40,
        "fifty": 50,
        "sixty": 60,
        "seventy": 70,
        "eighty": 80,
        "ninety": 90,
    }

    return switcher.get(value, "nothing")
  
# Get integer words 
x = raw_input("Please enter a number: ").lower()
y = raw_input("Please enter another number: ").lower()

# split them to a array 
arr1 = x.split("-")
arr2 = y.split("-")

# Check the integer is one-digit or two-digit and convert to integer
if len(arr1) == 1:
	a = int(oneWord(arr1[0])) 
elif len(arr1) == 2:
	a = int(oneWord(arr1[0])) + int(oneWord(arr1[1]))
else:
	print("The first number you enter is out of range")

if len(arr2) == 1:
        b = int(oneWord(arr2[0]))
elif len(arr2) == 2:
        b = int(oneWord(arr2[0])) + int(oneWord(arr2[1]))
else:
        print("The second number you enter is out of range")   

#Print the word as integer
print("The first number you enter is: " + str(a))
print("The second number you enter is: " + str(b))

#Multiple those two number
res = a * b
# printing result  
print("The product of those two number is: " + str(res))  
