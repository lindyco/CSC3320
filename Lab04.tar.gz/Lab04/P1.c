/*Lab04 Problem 1*/

#include <stdio.h>
   int main(){
	char String[100];
	printf("Enter an string \n");
	scanf("%s", String);
	printf("The String you entered is: %s\n", String);

}
