// Final Exam Problem5:

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void main(){
	system("cp FINALinstruction FINALinstruction.sh listFile P5 P5.c FINALc/copies");

	system("cp FINALinstruction FINALinstruction.sh listFile P5 P5.c FINALpython/copies");

}

