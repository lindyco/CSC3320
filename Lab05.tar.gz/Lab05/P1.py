#  Lab05 Problem 1

Value = raw_input("Enter an string: ")

print ("The string you enter is: %s" % Value)


