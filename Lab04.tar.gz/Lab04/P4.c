/*Lab04 Problem4*/

#include <stdio.h>

   int main(){
	int a;
	int sum = 0;
	for(a = 0; a < 1000; a++){
	   if(a % 3 == 0 || a % 5 == 0){
		sum = sum + a;
   }
  }
	printf("The sum all the integers below 1000 that are multiples of 3 or 5 is %d \n", sum);
}

