# Lab06 Problem1

from os import system

#Read the file as binary file
input_data = open("P1.txt", "rb").read()

# Write a file as binary file
f = open("P1_result.txt", "wb")
f.write(input_data)
f.close()

