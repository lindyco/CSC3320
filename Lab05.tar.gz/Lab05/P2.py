# Lab04 Problem2

Value = input("Enter a input: ")

print("The input you enter as an integer is: %i " % int(Value))
